package com.practica.api.client;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.time.LocalDate;
import java.util.HashMap;

public class RequestHelper {

  public static String prepareRequest()  {
    var values = new HashMap<String, Object>();
    values.put("firstName", "John");
    values.put("lastName", "Doe");
    values.put("birthDate", LocalDate.of(1985, 2, 5));

    var objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    String requestBody = null;
    try {
      requestBody = objectMapper.writeValueAsString(values);
    } catch (JsonProcessingException e) {
      throw new RuntimeException(e);
    }

    return requestBody;
  }
}
