package com.practica.api.client;

public interface URLConstants {

  String API_BASE_URL = "http://localhost:8080/students";


}
