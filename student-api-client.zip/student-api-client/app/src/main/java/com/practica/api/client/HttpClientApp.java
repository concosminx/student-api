package com.practica.api.client;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpClient.Version;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;

/**
 * Uses Java HTTP Client to call GET|POST endpoints
 */
public class HttpClientApp {

  /**
   * Sends Request (Async) for GET Endpoint
   * @throws URISyntaxException
   */
  public void invoke() throws URISyntaxException {
    HttpClient client = HttpClient.newBuilder().version(Version.HTTP_2).followRedirects(Redirect.NORMAL).build();
    HttpRequest request = HttpRequest.newBuilder()
            .uri(new URI(URLConstants.API_BASE_URL))
            .GET()
            .header("Accept", "application/json")
            .timeout(Duration.ofSeconds(10))
            .build();

    client.sendAsync(request, BodyHandlers.ofString())
            .thenApply(HttpResponse::body)
            .thenAccept(System.out::println)
            .join();
  }

  /**
   * Sends Request (Sync) for POST Endpoint
   * @throws URISyntaxException
   */
  public void invokePost() throws URISyntaxException {
    try {
      String requestBody = RequestHelper.prepareRequest();
      HttpClient client = HttpClient.newHttpClient();
      HttpRequest request = HttpRequest.newBuilder().uri(new URI(URLConstants.API_BASE_URL))
              .POST(HttpRequest.BodyPublishers.ofString(requestBody))
              .header("Accept", "application/json")
              .header("Content-Type", "application/json")
              .build();

      HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

      System.out.println(response.body());
    } catch (IOException | InterruptedException e) {
      e.printStackTrace();
    }
  }

  public static void main(String[] args) throws URISyntaxException {
    HttpClientApp httpClientApp = new HttpClientApp();
    httpClientApp.invokePost();
    httpClientApp.invoke();
  }

}
