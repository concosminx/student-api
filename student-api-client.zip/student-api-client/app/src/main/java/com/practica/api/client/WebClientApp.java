package com.practica.api.client;

import org.apache.hc.client5.http.ClientProtocolException;
import org.apache.hc.core5.http.ParseException;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;

/**
 * Uses Spring WebClient to call GET|POST endpoints
 */
public class WebClientApp {
  public void invoke() {
    WebClient client = WebClient.create();
    String result = client
            .get()
            .uri(URLConstants.API_BASE_URL)
            .header("Accept", "application/json")
            .retrieve()
            .bodyToMono(String.class)
            .block();
    //.subscribe(result->System.out.println(result))
    ;

    System.out.println("result::" + result);

  }

  public void invokePost() {
    WebClient client = WebClient.create();

    String result = client
            .post()
            .uri(URLConstants.API_BASE_URL)
            .body(BodyInserters.fromValue(RequestHelper.prepareRequest()))
            .header("Content-Type", "application/json")
            .exchange()
            .flatMap(response -> response.bodyToMono(String.class))
            .block();

    System.out.println("result::" + result);
  }


  public static void main(String[] args) throws ClientProtocolException, IOException, ParseException {
    WebClientApp webClientApp = new WebClientApp();
    webClientApp.invokePost();
    webClientApp.invoke();
  }
}
