package com.practica.api.client;

import okhttp3.*;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.concurrent.TimeUnit;

/**
 * Uses OkHttp Client to call GET|POST endpoints
 */
public class OkHttpClientApp {
  public void invoke() throws URISyntaxException, IOException {
    OkHttpClient client = new OkHttpClient.Builder()
            .readTimeout(1000, TimeUnit.MILLISECONDS)
            .writeTimeout(1000, TimeUnit.MILLISECONDS)
            .build();

    Request request = new Request.Builder()
            .url(URLConstants.API_BASE_URL)
            .get()
            .addHeader("Accept", "application/json")
            .build();

    Call call = client.newCall(request);
    call.enqueue(new Callback() {
      public void onResponse(Call call, Response response)
              throws IOException {
        System.out.println(response.body().string());
      }

      public void onFailure(Call call, IOException e) {
        // error
      }
    });

  }

  public void invokePost() throws URISyntaxException, IOException {
    OkHttpClient client = new OkHttpClient.Builder()
            .readTimeout(1000, TimeUnit.MILLISECONDS)
            .writeTimeout(1000, TimeUnit.MILLISECONDS)
            .build();

    String requestBody = RequestHelper.prepareRequest();

    RequestBody body = RequestBody.create(
            requestBody,
            MediaType.parse("application/json"));

    Request request = new Request.Builder()
            .url(URLConstants.API_BASE_URL)
            .post(body)
            .addHeader("Accept", "application/xml")
            .build();

    Response response = client.newCall(request).execute();
    System.out.println(response.body().string());
  }

  public static void main(String[] args) throws URISyntaxException, IOException {
    OkHttpClientApp okHttpClientApp = new OkHttpClientApp();
    okHttpClientApp.invokePost();
    okHttpClientApp.invoke();
  }
}
